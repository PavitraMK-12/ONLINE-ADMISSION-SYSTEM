from django.core.mail import send_mail
import smtplib

class CommonUtils:
    def send_email(self, username, msg_template):
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login("mcaminiproject2k18@gmail.com", "Mca@123456")
        server.sendmail(
            "mcaminiproject2k18@gmail.com",
            username,
            msg_template)
        server.quit()