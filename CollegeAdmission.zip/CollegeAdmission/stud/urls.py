from sys import path

from django.views.generic import TemplateView

from . import views
from django.conf.urls import url


urlpatterns = [
    url(r'^$', views.main, name='main'),
    url(r'login$', views.login, name='login'),
    url(r'user_login/', views.user_login, name='user_login'),
    url(r'success/', views.success, name='user_success'),
    url(r'admin_dash/$', views.admin_dash, name='admin_dash'),
    url(r'stud_dash', views.stud_dash, name='stud_dash'),
    url(r'stud_login/', views.stud_login, name='stud_login'),
    url(r'signup/', views.signup, name='signup'),
    #url(r'logout/$', views.logout, name='logout'),
    url(r'base2/', views.base2, name='base2'),
    url(r'apply_now/', views.apply_now, name='apply_now'),
    #url(r'studInsert2', views.upload_stud, name="studInsert2"),
url(r'studInsert2', views.upload_stud, name="studInsert2"),
url(r'academic', views.upload_academic, name="academic"),
     #url(r'sslc$', views.upload_sslc, name="sslc"),
    # url(r'puc$', views.upload_puc, name="puc"),
    url(r'add$', views.upload_add, name="add"),
url(r'gen$', views.gen, name="gen"),
    url(r'main$', views.main, name="main"),
    # url(r'degree$', views.upload_degree, name="degree"),
    url(r'Parent2/$', views.upload_parent2, name="Parent2"),
     url(r'stud_view/$', views.stud_view, name='stud_view'),
    url(r'generate_usn$', views.generate_usn, name='generate_usn'),
    url(r'mail/$', views.mail, name='mail'),
    url(r'uploadcourse1/$', views.upload_course1, name='uploadcourse1'),
    url(r'insertpersonal/$', views.insert_personal, name='insertpersonal'),
    url(r'stud_delete/$' , views.stud_delete, name='stud_delete'),
    url(r'stud/$', views.upload_stud),
url(r'payment$', views.payment, name="payment"),
    url(r'contact$', views.upload_cont, name="contact"),
    url(r'about$', views.upload_about, name="about"),
url(r'^create$', views.create, name='create'),
    url(r'index$', views.index, name="index"),
    url(r'edit/(?P<id>\d+)$', views.edit, name='edit'),
    url(r'^edit/update/(?P<id>\d+)$', views.update, name='update'),
    url(r'^delete/(?P<id>\d+)$', views.delete, name='delete'),
    url(r'create1$', views.create1, name='create1'),
# url(r'^delete/$', views.delete, name='delete'),


]

