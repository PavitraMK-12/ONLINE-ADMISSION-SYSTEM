from django.apps import AppConfig


class StudConfig(AppConfig):
    name = 'stud'
