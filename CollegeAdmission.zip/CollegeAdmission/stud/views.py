from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse

from CollegeAdmission.common_utils import CommonUtils
from stud.forms import StudForm, AcademicForm, Parent2Form, CourseForm, UsnForm
from stud.models import studentt, setupseats


# from stud.forms import  Stud11Form


def main(request):
    return render(request, 'main.html')


def admin_dash(request):
    return render(request, 'admin_dash.html')


def apply_now(request):
    return render(request, 'apply_now.html')


def gen(request):
    return render(request, 'gen.html')

def payment(request):
    return render(request, 'payment.html')


def stud_dash(request):
    return render(request, 'stud_dash.html')

def upload_cont(request):
    return render(request, 'contact.html')

def upload_about(request):
    return render(request, 'about.html')




def upload_add(request):
    return render(request, 'add.html')


def upload_sslc(request):
    return render(request, 'sslc.html')


def user_login(request):
    context = {}
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return HttpResponseRedirect(reverse('admin_dash'))
        else:
            context["error"] = "provide valid details"

            return render(request, "registration/login.html", context)
    else:

        return render(request, "registration/login.html", context)


def success(request):
    context = {}
    context['user'] = request.user
    return render(request, "registration/success.html", context)


from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect


@login_required
def home2(request):
    return render(request, 'home2.html')


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('signup')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})


def stud_login(request):
    if request.method == 'GET':
        return render(request, 'stud_login.html')
    else:
        validate_user = authenticate(
            username=request.POST.get('username', False),
            password=request.POST.get('password', False))
        if validate_user:
            login(request, validate_user)
            return render(request, 'stud_dash.html')
        else:
            return render(request, 'stud_login.html')


def base2(request):
    return render(request, 'base2.html')


def logout(request):
    return render(request, 'stud_login.html')


def upload_stud(request):
    if request.method == 'POST':
        stud_form = StudForm(request.POST)
        if stud_form.is_valid():
            post_stud = stud_form.save(commit=False)

            post_stud.save()

            return render(request, 'academicdetails.html')
    if request.method == 'GET':
        return render(request, 'studInsert2.html')

def upload_course1(request):
    if request.method == 'POST':
        course_form = CourseForm(request.POST)
        if course_form.is_valid():
            post_course = course_form.save(commit=False)

            post_course.save()

            return render(request, 'insertt.html')
    if request.method == 'GET':
        return render(request, 'course1.html')





def upload_academic(request):
    if request.method == 'POST':
        academic_form = AcademicForm(request.POST)
        if academic_form.is_valid():
            post_academic = academic_form.save(commit=False)
            post_academic.save()
            return HttpResponseRedirect('/Parent2')
    if request.method == 'GET':
        return render(request, 'academicdetails.html')


# def upload_stud11(request):
#     if request.method == 'POST':
#         stud11_form = Stud11Form(request.POST, request.FILES)
#         if stud11_form.is_valid():
#             post_stud11 = stud11_form.save(commit=False)
#             post_stud11.save()
#             return HttpResponseRedirect('/stud')
#     if request.method == 'GET':
#         return render(request, 'studInsert2.html')

# def upload_sslc(request):
#     if request.method == 'POST':
#         sslc_form = SslcForm(request.POST, request.FILES)
#         if sslc_form.is_valid():
#             post_sslc = sslc_form.save(commit=False)
#             post_sslc.save()
#             return HttpResponseRedirect('sslc/stud')
#     if request.method == 'GET':
#         return render(request, 'sslc.html')

# def upload_puc(request):
#     if request.method == 'POST':
#         puc_form = PucForm(request.POST, request.FILES)
#         if puc_form.is_valid():
#             post_puc = puc_form.save(commit=False)
#             post_puc.save()
#             return HttpResponseRedirect('puc/stud')
#     if request.method == 'GET':
#         return render(request, 'puc.html')
#
# def upload_degree(request):
#     if request.method == 'POST':
#         degree_form = DegreeForm(request.POST, request.FILES)
#         if degree_form.is_valid():
#             post_degree = degree_form.save(commit=False)
#             post_degree.save()
#             return HttpResponseRedirect('degree/stud')
#     if request.method == 'GET':
#         return render(request, 'degree.html')
#
#
#
def upload_parent2(request):
    if request.method == 'POST':
        parent2_form = Parent2Form(request.POST, request.FILES)
        if parent2_form.is_valid():
            post_parent2 = parent2_form.save(commit=False)
            post_parent2.save()
            messages.success(request, 'INSERTED SUCCESSFULLY!!')
        return HttpResponseRedirect('/stud_dash')
    if request.method == 'GET':
        return render(request, 'Parent2.html')


def stud_delete(request):
    if request.method == 'POST':
        sid = request.POST.get('id', '')

        std = studentt.objects.get(id=sid)
        std.delete()
        stud1 = studentt.objects.all()

        return render(request, 'studview.html', {'stud1': stud1})


def stud_view(request):
    stud1 = studentt.objects.all()
    return render(request, 'studview.html', {'stud1': stud1})


def generate_usn(request):
    stud1 = studentt.objects.all()

    return render(request, 'generate_usn.html', {'stud1': stud1})


def mail(request):
    if request.method == 'POST':
        usn_form = UsnForm(request.POST)
        if usn_form.is_valid():
            post_usn = usn_form.save(commit=False)
            post_usn.save()
            CommonUtils().send_email(
                request.POST['Email'],
                'Your Temporary USN: 01FM19')
            return HttpResponseRedirect('/stud/generate_usn')
        if request.method == 'GET':
            return render(request, 'generate_usn.html')





def insert_personal(request):
    if request.method == 'POST':
        stud_form = StudForm(request.POST)
        if stud_form.is_valid():
            post_stud = stud_form.save(commit=False)

            post_stud.save()

            return HttpResponseRedirect('/academicdetails')
    if request.method == 'GET':
        return render(request, 'studInsert2.html')

def create1(request):
    members = setupseats.objects.all()
    context = {'members': members}
    return render(request, 'index.html', context)

def create(request):
    member1 = setupseats(course=request.POST['course'], NoOfSeats=request.POST['NoOfSeats'], criteria=request.POST['criteria'])
    member1.save()
    return redirect('create1')

def index(request):
    members = setupseats.objects.all()
    context = {'members': members}
    return render(request, 'index.html', context)

def edit(request, id):
    members = setupseats.objects.get(id=id)
    context = {'members': members}
    return render(request, 'edit.html', context)

def update(request, id):
    member1 = setupseats.objects.get(id=id)
    member1.course = request.POST['course']
    member1.NoOfSeats = request.POST['NoOfSeats']
    member1.criteria = request.POST['criteria']
    member1.save()
    return redirect('/stud/index')


def delete(request, id):
    member1 = setupseats.objects.get(id=id)
    member1.delete()
    return redirect('/stud/index')