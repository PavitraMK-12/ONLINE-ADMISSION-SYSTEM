from django.contrib.auth.models import User
from django.db import models
# Create your models here.
# class stud(models.Model):
#
#     FirstName = models.CharField(max_length=100)
#     LastName = models.CharField(max_length=100)
#     PhoneNo = models.IntegerField()
#     AadharNo = models.IntegerField()
#     DOB = models.DateTimeField()
#     Nationality = models.CharField(max_length=100)
#     Email = models.CharField(max_length=100)
#     Gender = models.CharField(max_length=10)
#     Address = models.CharField(max_length=100)

class studentt(models.Model):
    FirstName = models.CharField(max_length=100)
    LastName = models.CharField(max_length=100)
    PhoneNo = models.IntegerField()
    AadharNo = models.IntegerField()

    Nationality = models.CharField(max_length=100)
    Email = models.CharField(max_length=100)
    Gender = models.CharField(max_length=10)
    Address = models.CharField(max_length=100)
    DOB = models.DateTimeField()

# class stud11(models.Model):
#
#     FirstName = models.CharField(max_length=100)
#     LastName = models.CharField(max_length=100)
#     PhoneNo = models.IntegerField()
#     AadharNo = models.CharField(max_length=100)
#     DOB = models.DateTimeField(max_length=100)
#     Nationality = models.CharField(max_length=100)
#     Email = models.CharField(max_length=100)
#     Gender = models.CharField(max_length=10)
#     Address = models.CharField(max_length=100)
#
#
class academic(models.Model):

    sslc_reg = models.IntegerField(null=True)
    school_name = models.CharField(max_length=100)
    max_marks = models.IntegerField(null=True)
    sec_marks = models.IntegerField(null=True)
    puc_reg = models.IntegerField(null=True)
    clg_name = models.CharField(max_length=100)
    pumax_marks = models.IntegerField(null=True)
    pusec_marks = models.IntegerField(null=True)
    degree_reg = models.IntegerField(null=True)
    uni_name = models.CharField(max_length=100)
    agg = models.IntegerField(null=True)

class parent(models.Model):
    FathersName = models.CharField(max_length=100)
    FOccupation = models.CharField(max_length=100)
    FPhoneNo = models.IntegerField(null=True)
    FAddress = models.CharField(max_length=100)
    MothersName = models.CharField(max_length=100)
    MOccupation = models.CharField(max_length=100)
    MAddress = models.CharField(max_length=100)
    MNumber = models.IntegerField(null=True)

class course1(models.Model):
    cet_reg = models.IntegerField(null=True)
    cet_rank = models.IntegerField(null=True)
    course = models.CharField(max_length=100)

class usn(models.Model):
    Email = models.CharField(max_length=100)

class setupseats(models.Model):
    course = (
        ('A', 'MCA'),
        ('B', 'MBA'),
        ('C', 'MTech'),
    )
    NoOfSeats = models.IntegerField(max_length=100)
    criteria = models.IntegerField(max_length=100)
    course = models.CharField(max_length=1, choices=course, default=course[1][0])

# Create your models here.
