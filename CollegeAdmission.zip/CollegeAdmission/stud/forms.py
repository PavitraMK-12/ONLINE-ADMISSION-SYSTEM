from django import forms
from stud.models import studentt, academic, parent, course1, usn

class StudForm(forms.ModelForm):
    class Meta:
        model = studentt
        fields = ('FirstName', 'LastName', 'PhoneNo', 'AadharNo',  'Nationality', 'Email', 'Gender', 'Address', 'DOB')

class AcademicForm(forms.ModelForm):
    class Meta:
        model = academic
        fields = ('sslc_reg', 'school_name', 'max_marks', 'sec_marks', 'puc_reg', 'clg_name', 'pumax_marks', 'pusec_marks', 'degree_reg', 'uni_name', 'agg')

class Parent2Form(forms.ModelForm):
    class Meta:

        model = parent
        fields = ( 'FathersName', 'FOccupation', 'FPhoneNo', 'FAddress', 'MothersName', 'MOccupation', 'MAddress',
                  'MNumber')

class CourseForm(forms.ModelForm):
    class Meta:
        model = course1
        fields = ('cet_reg', 'cet_rank', 'course')

class UsnForm(forms.ModelForm):
    class Meta:
        model = usn
        fields = ('Email',)
